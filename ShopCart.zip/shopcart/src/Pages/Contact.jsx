import React from 'react'

export default function Contact() {
  return (
    <div>
      Contact us page...
    </div>
  )
}
